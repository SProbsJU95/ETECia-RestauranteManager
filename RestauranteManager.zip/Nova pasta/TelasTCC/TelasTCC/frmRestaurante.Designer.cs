﻿namespace TelasTCC
{
    partial class frmRestaurante
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnEnviarSobremesa = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtSobremesaQtde = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cbDoce = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cbSorvete = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.gbBebida = new System.Windows.Forms.GroupBox();
            this.btnEnviarBebida = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtBebidadaQtde = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cb2l = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cb600ml = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbLata = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cbSuco = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cbDose = new System.Windows.Forms.ComboBox();
            this.gbFeijoada = new System.Windows.Forms.GroupBox();
            this.btnEnviarRefeicao = new System.Windows.Forms.Button();
            this.gbEscolha = new System.Windows.Forms.GroupBox();
            this.radPeso = new System.Windows.Forms.RadioButton();
            this.radPratoFeito = new System.Windows.Forms.RadioButton();
            this.radFeijoada = new System.Windows.Forms.RadioButton();
            this.txtPeso = new System.Windows.Forms.TextBox();
            this.cbRefeicao = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnEnviarTudo = new System.Windows.Forms.Button();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.gbBebida.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.gbFeijoada.SuspendLayout();
            this.gbEscolha.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnEnviarSobremesa);
            this.groupBox6.Controls.Add(this.groupBox7);
            this.groupBox6.Controls.Add(this.cbDoce);
            this.groupBox6.Controls.Add(this.label11);
            this.groupBox6.Controls.Add(this.cbSorvete);
            this.groupBox6.Controls.Add(this.label10);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.groupBox6.Location = new System.Drawing.Point(576, 155);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(271, 252);
            this.groupBox6.TabIndex = 6;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Sobremesas";
            // 
            // btnEnviarSobremesa
            // 
            this.btnEnviarSobremesa.BackColor = System.Drawing.Color.White;
            this.btnEnviarSobremesa.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnviarSobremesa.Location = new System.Drawing.Point(16, 204);
            this.btnEnviarSobremesa.Name = "btnEnviarSobremesa";
            this.btnEnviarSobremesa.Size = new System.Drawing.Size(196, 34);
            this.btnEnviarSobremesa.TabIndex = 3;
            this.btnEnviarSobremesa.Text = "Enviar sobremesa(s)";
            this.btnEnviarSobremesa.UseVisualStyleBackColor = false;
            this.btnEnviarSobremesa.Click += new System.EventHandler(this.btnEnviarSobremesa_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtSobremesaQtde);
            this.groupBox7.Controls.Add(this.label12);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(16, 136);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(213, 62);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Quantidade de doces";
            // 
            // txtSobremesaQtde
            // 
            this.txtSobremesaQtde.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtSobremesaQtde.Location = new System.Drawing.Point(117, 30);
            this.txtSobremesaQtde.Name = "txtSobremesaQtde";
            this.txtSobremesaQtde.Size = new System.Drawing.Size(79, 26);
            this.txtSobremesaQtde.TabIndex = 0;
            this.txtSobremesaQtde.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSobremesaQtde_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(19, 33);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(92, 20);
            this.label12.TabIndex = 10;
            this.label12.Text = "Quantidade";
            // 
            // cbDoce
            // 
            this.cbDoce.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cbDoce.FormattingEnabled = true;
            this.cbDoce.Location = new System.Drawing.Point(83, 95);
            this.cbDoce.Name = "cbDoce";
            this.cbDoce.Size = new System.Drawing.Size(146, 28);
            this.cbDoce.TabIndex = 1;
            this.cbDoce.Click += new System.EventHandler(this.cbDoce_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(12, 98);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 20);
            this.label11.TabIndex = 12;
            this.label11.Text = "Doces";
            // 
            // cbSorvete
            // 
            this.cbSorvete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cbSorvete.FormattingEnabled = true;
            this.cbSorvete.Location = new System.Drawing.Point(83, 47);
            this.cbSorvete.Name = "cbSorvete";
            this.cbSorvete.Size = new System.Drawing.Size(146, 28);
            this.cbSorvete.TabIndex = 0;
            this.cbSorvete.Click += new System.EventHandler(this.cbSorvete_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(12, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 20);
            this.label10.TabIndex = 10;
            this.label10.Text = "Sorvete";
            // 
            // gbBebida
            // 
            this.gbBebida.Controls.Add(this.btnEnviarBebida);
            this.gbBebida.Controls.Add(this.groupBox5);
            this.gbBebida.Controls.Add(this.label8);
            this.gbBebida.Controls.Add(this.cb2l);
            this.gbBebida.Controls.Add(this.label7);
            this.gbBebida.Controls.Add(this.cb600ml);
            this.gbBebida.Controls.Add(this.label6);
            this.gbBebida.Controls.Add(this.cbLata);
            this.gbBebida.Controls.Add(this.label5);
            this.gbBebida.Controls.Add(this.cbSuco);
            this.gbBebida.Controls.Add(this.label4);
            this.gbBebida.Controls.Add(this.cbDose);
            this.gbBebida.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.gbBebida.Location = new System.Drawing.Point(22, 155);
            this.gbBebida.Name = "gbBebida";
            this.gbBebida.Size = new System.Drawing.Size(537, 252);
            this.gbBebida.TabIndex = 5;
            this.gbBebida.TabStop = false;
            this.gbBebida.Text = "Bebidas";
            // 
            // btnEnviarBebida
            // 
            this.btnEnviarBebida.BackColor = System.Drawing.Color.White;
            this.btnEnviarBebida.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnviarBebida.Location = new System.Drawing.Point(303, 188);
            this.btnEnviarBebida.Name = "btnEnviarBebida";
            this.btnEnviarBebida.Size = new System.Drawing.Size(185, 34);
            this.btnEnviarBebida.TabIndex = 6;
            this.btnEnviarBebida.Text = "Enviar bebida(s)";
            this.btnEnviarBebida.UseVisualStyleBackColor = false;
            this.btnEnviarBebida.Click += new System.EventHandler(this.btnEnviarBebida_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtBebidadaQtde);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(304, 103);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(213, 62);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Quantidade de bebidas";
            // 
            // txtBebidadaQtde
            // 
            this.txtBebidadaQtde.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtBebidadaQtde.Location = new System.Drawing.Point(117, 30);
            this.txtBebidadaQtde.Name = "txtBebidadaQtde";
            this.txtBebidadaQtde.Size = new System.Drawing.Size(79, 26);
            this.txtBebidadaQtde.TabIndex = 0;
            this.txtBebidadaQtde.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBebidadaQtde_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(19, 33);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 20);
            this.label9.TabIndex = 10;
            this.label9.Text = "Quantidade";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(266, 55);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(114, 20);
            this.label8.TabIndex = 18;
            this.label8.Text = "Refrigerante 2l";
            // 
            // cb2l
            // 
            this.cb2l.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cb2l.FormattingEnabled = true;
            this.cb2l.Location = new System.Drawing.Point(386, 52);
            this.cb2l.Name = "cb2l";
            this.cb2l.Size = new System.Drawing.Size(133, 28);
            this.cb2l.TabIndex = 4;
            this.cb2l.Click += new System.EventHandler(this.cb2l_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(25, 202);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 20);
            this.label7.TabIndex = 16;
            this.label7.Text = "600 ml";
            // 
            // cb600ml
            // 
            this.cb600ml.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cb600ml.FormattingEnabled = true;
            this.cb600ml.Location = new System.Drawing.Point(119, 199);
            this.cb600ml.Name = "cb600ml";
            this.cb600ml.Size = new System.Drawing.Size(133, 28);
            this.cb600ml.TabIndex = 3;
            this.cb600ml.Click += new System.EventHandler(this.cb600ml_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(25, 152);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 20);
            this.label6.TabIndex = 14;
            this.label6.Text = "Lata";
            // 
            // cbLata
            // 
            this.cbLata.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cbLata.FormattingEnabled = true;
            this.cbLata.Location = new System.Drawing.Point(119, 149);
            this.cbLata.Name = "cbLata";
            this.cbLata.Size = new System.Drawing.Size(133, 28);
            this.cbLata.TabIndex = 2;
            this.cbLata.Click += new System.EventHandler(this.cbLata_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(25, 103);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 20);
            this.label5.TabIndex = 12;
            this.label5.Text = "Suco";
            // 
            // cbSuco
            // 
            this.cbSuco.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cbSuco.FormattingEnabled = true;
            this.cbSuco.Location = new System.Drawing.Point(119, 100);
            this.cbSuco.Name = "cbSuco";
            this.cbSuco.Size = new System.Drawing.Size(133, 28);
            this.cbSuco.TabIndex = 1;
            this.cbSuco.Click += new System.EventHandler(this.cbSuco_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(25, 55);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 20);
            this.label4.TabIndex = 10;
            this.label4.Text = "Doses";
            // 
            // cbDose
            // 
            this.cbDose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cbDose.FormattingEnabled = true;
            this.cbDose.Location = new System.Drawing.Point(119, 52);
            this.cbDose.Name = "cbDose";
            this.cbDose.Size = new System.Drawing.Size(133, 28);
            this.cbDose.TabIndex = 0;
            this.cbDose.Click += new System.EventHandler(this.cbDose_Click);
            // 
            // gbFeijoada
            // 
            this.gbFeijoada.Controls.Add(this.btnEnviarRefeicao);
            this.gbFeijoada.Controls.Add(this.gbEscolha);
            this.gbFeijoada.Controls.Add(this.txtPeso);
            this.gbFeijoada.Controls.Add(this.cbRefeicao);
            this.gbFeijoada.Controls.Add(this.label1);
            this.gbFeijoada.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbFeijoada.Location = new System.Drawing.Point(22, 31);
            this.gbFeijoada.Name = "gbFeijoada";
            this.gbFeijoada.Size = new System.Drawing.Size(825, 106);
            this.gbFeijoada.TabIndex = 4;
            this.gbFeijoada.TabStop = false;
            this.gbFeijoada.Text = "Refeição";
            // 
            // btnEnviarRefeicao
            // 
            this.btnEnviarRefeicao.BackColor = System.Drawing.Color.White;
            this.btnEnviarRefeicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnviarRefeicao.Location = new System.Drawing.Point(608, 52);
            this.btnEnviarRefeicao.Name = "btnEnviarRefeicao";
            this.btnEnviarRefeicao.Size = new System.Drawing.Size(185, 34);
            this.btnEnviarRefeicao.TabIndex = 2;
            this.btnEnviarRefeicao.Text = "Enviar refeição";
            this.btnEnviarRefeicao.UseVisualStyleBackColor = false;
            this.btnEnviarRefeicao.Click += new System.EventHandler(this.btnEnviarRefeicao_Click);
            // 
            // gbEscolha
            // 
            this.gbEscolha.Controls.Add(this.radPeso);
            this.gbEscolha.Controls.Add(this.radPratoFeito);
            this.gbEscolha.Controls.Add(this.radFeijoada);
            this.gbEscolha.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbEscolha.Location = new System.Drawing.Point(29, 34);
            this.gbEscolha.Name = "gbEscolha";
            this.gbEscolha.Size = new System.Drawing.Size(306, 56);
            this.gbEscolha.TabIndex = 0;
            this.gbEscolha.TabStop = false;
            this.gbEscolha.Text = "Escolha";
            // 
            // radPeso
            // 
            this.radPeso.AutoSize = true;
            this.radPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.radPeso.Location = new System.Drawing.Point(227, 23);
            this.radPeso.Name = "radPeso";
            this.radPeso.Size = new System.Drawing.Size(63, 24);
            this.radPeso.TabIndex = 3;
            this.radPeso.TabStop = true;
            this.radPeso.Text = "Peso";
            this.radPeso.UseVisualStyleBackColor = true;
            this.radPeso.CheckedChanged += new System.EventHandler(this.radPeso_CheckedChanged);
            // 
            // radPratoFeito
            // 
            this.radPratoFeito.AutoSize = true;
            this.radPratoFeito.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.radPratoFeito.Location = new System.Drawing.Point(121, 23);
            this.radPratoFeito.Name = "radPratoFeito";
            this.radPratoFeito.Size = new System.Drawing.Size(100, 24);
            this.radPratoFeito.TabIndex = 2;
            this.radPratoFeito.TabStop = true;
            this.radPratoFeito.Text = "Prato feito";
            this.radPratoFeito.UseVisualStyleBackColor = true;
            this.radPratoFeito.CheckedChanged += new System.EventHandler(this.radPratoFeito_CheckedChanged);
            // 
            // radFeijoada
            // 
            this.radFeijoada.AutoSize = true;
            this.radFeijoada.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.radFeijoada.Location = new System.Drawing.Point(27, 23);
            this.radFeijoada.Name = "radFeijoada";
            this.radFeijoada.Size = new System.Drawing.Size(88, 24);
            this.radFeijoada.TabIndex = 1;
            this.radFeijoada.TabStop = true;
            this.radFeijoada.Text = "Feijoada";
            this.radFeijoada.UseVisualStyleBackColor = true;
            this.radFeijoada.CheckedChanged += new System.EventHandler(this.radFeijoada_CheckedChanged);
            // 
            // txtPeso
            // 
            this.txtPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtPeso.Location = new System.Drawing.Point(431, 57);
            this.txtPeso.Name = "txtPeso";
            this.txtPeso.Size = new System.Drawing.Size(100, 26);
            this.txtPeso.TabIndex = 1;
            this.txtPeso.Visible = false;
            this.txtPeso.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPeso_KeyPress);
            // 
            // cbRefeicao
            // 
            this.cbRefeicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cbRefeicao.FormattingEnabled = true;
            this.cbRefeicao.Location = new System.Drawing.Point(431, 57);
            this.cbRefeicao.Name = "cbRefeicao";
            this.cbRefeicao.Size = new System.Drawing.Size(146, 28);
            this.cbRefeicao.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(352, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Refeição";
            // 
            // btnEnviarTudo
            // 
            this.btnEnviarTudo.BackColor = System.Drawing.Color.White;
            this.btnEnviarTudo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnviarTudo.Location = new System.Drawing.Point(22, 431);
            this.btnEnviarTudo.Name = "btnEnviarTudo";
            this.btnEnviarTudo.Size = new System.Drawing.Size(185, 34);
            this.btnEnviarTudo.TabIndex = 7;
            this.btnEnviarTudo.Text = "Enviar pedido";
            this.btnEnviarTudo.UseVisualStyleBackColor = false;
            this.btnEnviarTudo.Click += new System.EventHandler(this.btnEnviarTudo_Click);
            // 
            // frmRestaurante
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(242)))), ((int)(((byte)(219)))));
            this.ClientSize = new System.Drawing.Size(869, 487);
            this.Controls.Add(this.btnEnviarTudo);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.gbBebida);
            this.Controls.Add(this.gbFeijoada);
            this.Name = "frmRestaurante";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tela de restaurante";
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.gbBebida.ResumeLayout(false);
            this.gbBebida.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.gbFeijoada.ResumeLayout(false);
            this.gbFeijoada.PerformLayout();
            this.gbEscolha.ResumeLayout(false);
            this.gbEscolha.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btnEnviarSobremesa;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txtSobremesaQtde;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cbDoce;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbSorvete;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox gbBebida;
        private System.Windows.Forms.Button btnEnviarBebida;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtBebidadaQtde;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cb2l;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cb600ml;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbLata;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbSuco;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbDose;
        private System.Windows.Forms.GroupBox gbFeijoada;
        private System.Windows.Forms.ComboBox cbRefeicao;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPeso;
        private System.Windows.Forms.GroupBox gbEscolha;
        private System.Windows.Forms.Button btnEnviarRefeicao;
        private System.Windows.Forms.Button btnEnviarTudo;
        private System.Windows.Forms.RadioButton radPeso;
        private System.Windows.Forms.RadioButton radPratoFeito;
        private System.Windows.Forms.RadioButton radFeijoada;
    }
}