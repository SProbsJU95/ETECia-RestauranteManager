﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Endereco;
using TelasTCC.DB.Funcionario;

namespace TelasTCC
{
    public partial class frmModFuncionarios : Form
    {
        public frmModFuncionarios()
        {
            InitializeComponent();

            Listar();
            this.Width = 780;
        }

        public void Listar()
        {
            FuncionarioBusiness business = new FuncionarioBusiness();
            List<FuncionarioDTO> lista = business.Listar();

            dgvFuncionario.AutoGenerateColumns = false;
            dgvFuncionario.DataSource = lista;
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            string id = this.dgvFuncionario.CurrentRow.Cells[0].Value.ToString();
            
            FuncionarioDatabase database = new FuncionarioDatabase();

            int val = 0;
            string msg = string.Empty;

            if(cbDados.Text == "CPF"){val = 0; msg = "CPF: "; }
            else if (cbDados.Text == "Data de nascimento") { val = 1; msg = "Data de nascimento: "; }
            else if (cbDados.Text == "Endereço") { val = 2; msg = "Endereço: "; }

            string campo = database.ListarFuncionario(val, id);
            lblInformacoes.Text = msg + campo;
        }

        private void btnAtuali_Click(object sender, EventArgs e)
        {
            gbAtualizar.Visible = true;
            FuncionarioDTO dto = new FuncionarioDTO();
            if (dgvFuncionario.SelectedRows !=null)
            {
                lblNome.Text = this.dgvFuncionario.CurrentRow.Cells[1].Value.ToString();
                lblSalario.Text = this.dgvFuncionario.CurrentRow.Cells[2].Value.ToString();
                lblFuncao.Text = this.dgvFuncionario.CurrentRow.Cells[3].Value.ToString();
                lblSituacao.Text = this.dgvFuncionario.CurrentRow.Cells[4].Value.ToString();
                lblTelefone.Text = this.dgvFuncionario.CurrentRow.Cells[5].Value.ToString();

                lblIdFunc.Text = this.dgvFuncionario.CurrentRow.Cells[0].Value.ToString();

                FuncionarioDatabase database = new FuncionarioDatabase();
                string id = lblIdFunc.Text;
                lblCpf.Text = database.Listar(id, "CPF");
                lblNascimento.Text = database.Listar(id, "data_de_nascimento");
                lblIdEndereco.Text = database.Listar(id, "Endereco_idEndereco");

                string idEndereco = lblIdEndereco.Text;
                lblRua.Text = database.ListarEndereco(idEndereco, "Rua");
                lblNumero.Text = database.ListarEndereco(idEndereco, "numero");
                lblCep.Text = database.ListarEndereco(idEndereco, "CEP");
                lblBairro.Text = database.ListarEndereco(idEndereco, "Bairro");
                
                lblNome.Text = this.dgvFuncionario.CurrentRow.Cells[1].Value.ToString();
                lblSalario.Text = this.dgvFuncionario.CurrentRow.Cells[2].Value.ToString();
                lblFuncao.Text = this.dgvFuncionario.CurrentRow.Cells[3].Value.ToString();
                lblSituacao.Text = this.dgvFuncionario.CurrentRow.Cells[4].Value.ToString();
                lblTelefone.Text = this.dgvFuncionario.CurrentRow.Cells[5].Value.ToString();

                TextBox();

                this.Width = 1351;
                gbAtualizar.Enabled = true;
            }

        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            string cf,cp,dn;
            if (txtNome.Text == "" || txtTelefone.Text == "" || txtCPF.Text == "" || txtSalario.Text == "" || txtFuncao.Text == "" || txtNascimento.Text == "" || txtRua.Text == "" || txtBairro.Text == "" || txtNumero.Text == "" || txtCep.Text == "")
            {
                MessageBox.Show("Preenchar todos os Campos", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                dn = txtNascimento.Text;
                cp = txtCep.Text;
                cf = txtCPF.Text;
                if (dn.Length != 8)
                {
                    MessageBox.Show("Data de Nascimento:" + dn + " invalida");
                }
                else if (cf.Length != 11)
                {
                    MessageBox.Show("CPF:" + cf + " invalido");
                }
                else if (cp.Length != 8)
                {
                    MessageBox.Show("CEP:" + cp + " invalido");
                }


                else
                {
                    FuncionarioDTO dto = new FuncionarioDTO();

                    dto.CPF = txtCPF.Text;
                    dto.Nascimento = txtNascimento.Text;
                    dto.Nome = txtNome.Text;
                    dto.Funcao = txtFuncao.Text; ;
                    dto.Situacao = txtSituacao.Text;
                    dto.Salario = txtSalario.Text;
                    dto.Telefone = txtTelefone.Text;

                    string cpf = lblCpf.Text;
                    FuncionarioBusiness business = new FuncionarioBusiness();
                    business.Editar(dto, cpf);

                    EnderecoDTO dtoe = new EnderecoDTO();
                    dtoe.Rua = txtRua.Text;
                    dtoe.Numero = txtNumero.Text;
                    dtoe.Cep = txtCep.Text;
                    dtoe.Bairro = txtBairro.Text;

                    string idEndereco = lblIdEndereco.Text;
                    EnderecoBusiness businessE = new EnderecoBusiness();
                    businessE.Editar(dtoe, idEndereco);

                    MessageBox.Show("Atualizado com sucesso.");

                    Listar();

                    this.Width = 795;
                }
            }
        }
                public void TextBox()
                {
                    txtCPF.Text = lblCpf.Text;
                    txtNascimento.Text = lblNascimento.Text;
                    txtRua.Text = lblRua.Text;
                    txtNumero.Text = lblNumero.Text;
                    txtCep.Text = lblCep.Text;
                    txtBairro.Text = lblBairro.Text;
                    txtNome.Text = lblNome.Text;
                    txtSalario.Text = lblSalario.Text;
                    txtFuncao.Text = lblFuncao.Text;
                    txtSituacao.Text = lblSituacao.Text;
                    txtTelefone.Text = lblTelefone.Text;

                    this.Width = 1360;
                }
            
        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Digite somente letras");
                e.Handled = true;
            }
        }

        private void txtSituacao_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Digite somente letras");
                e.Handled = true;
            }
        }

      

        private void txtFuncao_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Digite somente letras");
                e.Handled = true;
            }
        }

        private void txtRua_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Digite somente letras");
                e.Handled = true;
            }
        }

        private void txtBairro_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Digite somente letras");
                e.Handled = true;
            }
        }

        private void txtSalario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Digite somente números");
                e.Handled = true;
            }
        }

        private void txtTelefone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Digite somente números");
                e.Handled = true;
            }
        }

        private void txtCPF_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Digite somente números");
                e.Handled = true;
            }
        }

        private void txtNascimento_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Digite somente números");
                e.Handled = true;
            }
        }

        private void txtCep_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Digite somente números");
                e.Handled = true;
            }
        }

       
    }
}
