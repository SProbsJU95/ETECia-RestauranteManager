﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelasTCC.DB.Financeiro
{
    class FinanceiroBusiness
    {
        public List<FinanceiroDTO> Listar()
        {
            FinanceiroDatabase db = new FinanceiroDatabase();
            return db.Listar();
        }

        public string ListarTotalVendas(string script)
        {
            FinanceiroDatabase database = new FinanceiroDatabase();
            return database.ListarTotalVendas(script);
        }
    }
}
