﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Base;
using TelasTCC.DB.Endereco;

namespace TelasTCC.DB.Fornecedores
{
    class FornecedoresDatabase
    {
        public int Salvar(FornecedoresDTO dto)
        {
            string script = @"insert into fornecedor(cnpj,nome,fornecimento,telefone_um,telefone_dois) values(@cnpj,@nome,@fornecimento,@telefone_um,@telefone_dois)";
            
            List<MySqlParameter> parms = new List<MySqlParameter>();
            
            parms.Add(new MySqlParameter("cnpj", dto.Cnpj));
            parms.Add(new MySqlParameter("nome", dto.Nome));
            parms.Add(new MySqlParameter("fornecimento", dto.Fornecimento));
            
            parms.Add(new MySqlParameter("telefone_um", dto.Telefone_um));
            parms.Add(new MySqlParameter("telefone_dois", dto.Telefone_dois));
            
            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }
        

        public List<FornecedoresDTO> Listar()
        {
            string script = "SELECT * FROM `fornecedor`";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FornecedoresDTO> lista = new List<FornecedoresDTO>();

            while (reader.Read())
            {
                FornecedoresDTO dto = new FornecedoresDTO();
                dto.Nome = reader.GetString("nome");
                dto.Telefone_um = reader.GetString("telefone_um");
                dto.Telefone_dois = reader.GetString("telefone_dois");
                dto.Fornecimento = reader.GetString("fornecimento");
                
                dto.Cnpj = reader.GetString("cnpj");

                lista.Add(dto);
            }
            reader.Close();

            return lista;
        }

        public int Atualizar(string cnpj ,FornecedoresDTO dto)
        {
            string script = @"update `fornecedor` set cnpj=@cnpj, nome=@nome, fornecimento=@fornecimento, telefone_um=@telefone_um, telefone_dois=@telefone_dois  where cnpj= '" + cnpj + " ';";
           
            List<MySqlParameter> parms = new List<MySqlParameter>();

            parms.Add(new MySqlParameter("cnpj", dto.Cnpj));
            parms.Add(new MySqlParameter("nome", dto.Nome));
            parms.Add(new MySqlParameter("fornecimento", dto.Fornecimento));
           
            parms.Add(new MySqlParameter("telefone_um", dto.Telefone_um));
            parms.Add(new MySqlParameter("telefone_dois", dto.Telefone_dois));

            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }
    }
}
