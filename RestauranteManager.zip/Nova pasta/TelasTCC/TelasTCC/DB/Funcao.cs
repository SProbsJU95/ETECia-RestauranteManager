﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelasTCC.DB.Login
{
    class Funcao
    {
        static string funcionarioFuncao = string.Empty;
        static string tellCliente = string.Empty;

        public void SetFuncao(string funcao)
        {
            funcionarioFuncao = funcao;
        }

        public string GetFuncao()
        {
            return funcionarioFuncao;
        }


        public void SetTellCliente(string tell)
        {
            tellCliente = tell;
        }

        public string GetTellCliente()
        {
            return tellCliente;
        }
    }
}
