﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Base;

namespace TelasTCC.DB.Funcionario
{
    class FuncionarioDatabase
    {
        public List<FuncionarioDTO> Listar()
        {
            string script = "SELECT CPF, nome, salario, funcao, telefone, situacao FROM `funcionario` WHERE funcao != 'adm'";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FuncionarioDTO> lista = new List<FuncionarioDTO>();

            while (reader.Read())
            {
                FuncionarioDTO dto = new FuncionarioDTO();
                dto.CPF = reader.GetString("CPF");
                dto.Nome = reader.GetString("nome");
                dto.Salario = reader.GetString("salario");
                dto.Funcao = reader.GetString("funcao");
                dto.Situacao = reader.GetString("situacao");
                dto.Telefone = reader.GetString("telefone");

                lista.Add(dto);
            }
            reader.Close();

            return lista;
        }

        public string ListarFuncionario(int i, string cpf)
        {
            string script = "SELECT f.CPF, f.data_de_nascimento, CONCAT(Rua,' - ', numero,' - ', Bairro) as Enderecos FROM `endereco` INNER JOIN `funcionario` as f WHERE f.Endereco_idEndereco = idEndereco and CPF = '"+cpf+"';";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FuncionarioDTO> listaSenha = new List<FuncionarioDTO>();

            string campo = "";

            while (reader.Read())
            {
                FuncionarioDTO dto = new FuncionarioDTO();
                try
                {
                    if (i == 0)
                    {
                        dto.Campo = reader.GetString("CPF");
                    }
                    else if (i == 1)
                    {
                        dto.Campo = reader.GetString("data_de_nascimento");
                        
                    }
                    else if (i == 2)
                    {
                        dto.Campo = reader.GetString("Enderecos");
                    }

                    campo = dto.Campo;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("" + ex);
                }
                
            }
            reader.Close();

            return campo;
        }
        public string Listar(string id, string campo)
        {
            string script = "select `" + campo + "`as campo from funcionario where CPF = '" + id + "';";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FuncionarioDTO> listaSenha = new List<FuncionarioDTO>();

            string valor = "";

            while (reader.Read())
            {
                FuncionarioDTO dto = new FuncionarioDTO();
                try {
                    dto.Campo = reader.GetString("campo");

                    valor = dto.Campo;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("" + ex);
                }
                }
            
            reader.Close();

            return valor;
        }

        public string ListarEndereco(string id, string campo)
        {
            string script = "select `" + campo + "`as campo from endereco where idEndereco = '" + id + "';";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FuncionarioDTO> listaSenha = new List<FuncionarioDTO>();

            string valor = "";

            while (reader.Read())
            {
                FuncionarioDTO dto = new FuncionarioDTO();
                dto.Campo = reader.GetString("campo");

                valor = dto.Campo;
            }
            reader.Close();

            return valor;
        }

        public int Editar(FuncionarioDTO dto, string cpf)
        {
            string script = @"UPDATE funcionario SET `nome`=@nome,`telefone`=@telefone,`salario`=@salario,`funcao`=@funcao,`data_de_nascimento`=@data_de_nascimento where CPF = '"+cpf+"';";

            List<MySqlParameter> parms = new List<MySqlParameter>();
            parms.Add(new MySqlParameter("nome", dto.Nome));
            parms.Add(new MySqlParameter("telefone", dto.Telefone));
            parms.Add(new MySqlParameter("salario", dto.Salario));
            parms.Add(new MySqlParameter("funcao", dto.Funcao));
            parms.Add(new MySqlParameter("data_de_nascimento", dto.Nascimento));

            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }
    }
}
