﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelasTCC.DB.Funcionario
{
    class FuncionarioBusiness
    {
        public List<FuncionarioDTO> Listar()
        {
            FuncionarioDatabase db = new FuncionarioDatabase();
            return db.Listar();
        }

        public int Editar(FuncionarioDTO dto,string cpf)
        {
            /*if (dto.Nome == string.Empty)
                throw new ArgumentException("Nome é obrigatório.");

            if (dto.Celular== string.Empty)
                throw new ArgumentException("Telefone é obrigatório.");

            if (dto.num_residencia == string.Empty)
                throw new ArgumentException("Número da residencia é obrigatório.");*/

            FuncionarioDatabase db = new FuncionarioDatabase();
            return db.Editar(dto,cpf);// EDITARRR
        }
    }
}
