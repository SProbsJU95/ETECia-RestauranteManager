﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Fornecedores;

namespace TelasTCC
{
    public partial class frmModFornecedores : Form
    {
        public frmModFornecedores()
        {
            InitializeComponent();
            
            ListarFornecedores();
        }

        public void ListarFornecedores()
        {
            FornecedoresBusiness business = new FornecedoresBusiness();
            List<FornecedoresDTO> lista = business.Listar();

            dgvFornecedores.AutoGenerateColumns = false;
            dgvFornecedores.DataSource = lista;
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            
            ChamarCadastro();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            FornecedoresDTO dto = new FornecedoresDTO();

            if (dgvFornecedores.SelectedRows != null||dgvFornecedores.RowCount==0)
            {
                lblCNPJ.Text = this.dgvFornecedores.CurrentRow.Cells[0].Value.ToString();
                lblFornecimento.Text = this.dgvFornecedores.CurrentRow.Cells[1].Value.ToString();
                lblNome.Text = this.dgvFornecedores.CurrentRow.Cells[2].Value.ToString();
                lblTelefone1.Text = this.dgvFornecedores.CurrentRow.Cells[3].Value.ToString();
                lblTelefone2.Text = this.dgvFornecedores.CurrentRow.Cells[4].Value.ToString();

                txtCNPJ.Text = lblCNPJ.Text;
                txtFornecimento.Text = lblFornecimento.Text;
                txtNome.Text = lblNome.Text;
                txtTelefone1.Text = lblTelefone1.Text;
                txtTelefone2.Text = lblTelefone2.Text;

                gbAtualizar.Visible = true;
                gbAtualizar.Enabled = true;

                this.Width = 1067;
            }
            else
            {
                MessageBox.Show("Selecione uma linha");
            }
        }

        public void ChamarCadastro()
        {
            Form cadFornecedores = new frmCadFornecedor();
            cadFornecedores.Show();
                                         
        }

        private void btnConcluir_Click(object sender, EventArgs e)
        {
            string cpj = txtCNPJ.Text;
            if (txtCNPJ.Text == "" || txtFornecimento.Text == "" || txtNome.Text == "" || txtTelefone1.Text == "" )
            {
                MessageBox.Show("Preencha todos os campos!!", "Atenção");
            }
            else if (cpj.Length != 18)
            {
                MessageBox.Show("O CNPJ: " + cpj + " é invalido");
            }
            else {
                FornecedoresDTO dto = new FornecedoresDTO();
                FornecedoresBusiness business = new FornecedoresBusiness();

                if (txtCNPJ != null) {
                    dto.Cnpj = txtCNPJ.Text;
                    dto.Fornecimento = txtFornecimento.Text;
                    dto.Nome = txtNome.Text;
                    dto.Telefone_um = txtTelefone1.Text;
                    dto.Telefone_dois = txtTelefone2.Text;

                    string cnpj = lblCNPJ.Text;
                    business.Atualizar(cnpj, dto);

                    gbAtualizar.Visible = false;
                    gbAtualizar.Enabled = false;

                    this.Width = 780;

                    MessageBox.Show("Fornecedor atualizado.");

                    ListarFornecedores();
                }
            }
        }
       
        private void btnAtualizar_Click_1(object sender, EventArgs e)
        {
            ListarFornecedores();
            
        }

        private void txtCNPJ_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Digite somente números");
                e.Handled = true;
            }
        }

        private void txtTelefone1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Digite somente números");
                e.Handled = true;
            }
        }

        private void txtTelefone2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Digite somente números");
                e.Handled = true;
            }
        }

        private void txtFornecimento_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Digite somente letras");
                e.Handled = true;
            }
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Digite somente letras");
                e.Handled = true;
            }
        }
    }
    }

